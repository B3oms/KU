const menuBtn = document.querySelector('.menu-btn');
const menuDropdown = document.querySelector('.menu-dropdown');

menuBtn.addEventListener('click', () => {
  menuDropdown.classList.toggle('hidden');
});
// JavaScript to toggle the dropdown menu
const departmentsMenu = document.querySelector('.menu-item');
const dropdown = document.querySelector('.dropdown');

departmentsMenu.addEventListener('click', () => {
  dropdown.classList.toggle('hidden');
});

