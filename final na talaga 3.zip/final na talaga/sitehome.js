const menuBtn = document.querySelector('.menu-btn');
const menuDropdown = document.querySelector('.menu-dropdown');

menuBtn.addEventListener('click', () => {
  menuDropdown.classList.toggle('hidden');
});
// JavaScript to toggle the dropdown menu
const departmentsMenu = document.querySelector('.menu-item');
const dropdown = document.querySelector('.dropdown');

departmentsMenu.addEventListener('click', () => {
  dropdown.classList.toggle('hidden');
});

// JavaScript to handle charts and dynamic content
document.addEventListener('DOMContentLoaded', () => {
  // Simulated ChartJS Data for the progress graph
  const ctx = document.getElementById('progressChart').getContext('2d');
  const progressChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
      datasets: [
        {
          label: 'Average Grade',
          data: [2.5, 2.8, 3.0, 2.7, 3.2, 3.1, 3.3, 3.5, 3.6, 3.8],
          borderColor: '#4caf50',
          backgroundColor: 'rgba(76, 175, 80, 0.2)',
          fill: true,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
    },
  });
});

function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  sidebar.classList.toggle('open');
}
